﻿Fahim Imtiaz
fmi89
06/30/2023




README.txt


Program Name: Equation Checker


The Equation Checker program verifies that parentheses, square brackets, and angle brackets are used correctly in expressions. One expression per line of a file containing the expressions is read.


Instructions to Compile and Run the Program:


1. Open a terminal or command prompt.
   
2. Navigate to the directory where your C files are located using the "cd" command.




3. Run the program with the following command:
   ./check Eq_check.txt   
  
If you follow these steps correctly, the Equation Checker program will read the expressions from the file, validate each one, and print the results to the console.